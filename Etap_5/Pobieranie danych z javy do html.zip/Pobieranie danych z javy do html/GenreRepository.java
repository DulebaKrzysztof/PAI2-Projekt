package com.example.pai2;

import org.springframework.data.repository.CrudRepository;


public interface GenreRepository extends CrudRepository<GenreEntityWorking,String> {
}
