package com.example.pai2;

import com.example.pai2.dto.ScreeningEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ScreeningRepository extends CrudRepository<ScreeningEntity,String> {

}
