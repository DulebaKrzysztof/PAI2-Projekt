package com.example.pai2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pai2Application {

    public static void main(String[] args) {
        SpringApplication.run(Pai2Application.class, args);
    }

}
