package pl.cinema.registrationAndLogin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import pl.cinema.registrationAndLogin.model.Role;
import pl.cinema.registrationAndLogin.model.User;
import pl.cinema.registrationAndLogin.repository.UserRepository;
import pl.cinema.registrationAndLogin.web.dto.UserRegistrationDto;

import java.util.Arrays;

@Component
public class SetupDataLoader implements
        ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if(userRepository.findByEmail("a@a.pl") == null) {
            User user = new User("a", "a", "a@a.pl",
                    passwordEncoder.encode("a"),
                    Arrays.asList(new Role("ROLE_ADMIN")));
            userRepository.save(user);
        }

        if(userRepository.findByEmail("p@p.pl") == null) {
            User user = new User("p", "p", "p@p.pl",
                    passwordEncoder.encode("p"),
                    Arrays.asList(new Role("ROLE_EMPLOYEE")));
            userRepository.save(user);
        }
    }
}