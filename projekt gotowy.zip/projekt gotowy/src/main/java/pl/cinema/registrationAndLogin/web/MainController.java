package pl.cinema.registrationAndLogin.web;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import pl.cinema.user.model.Screening;

@Controller
public class MainController {

	@GetMapping("/about")
	public String test(Model model) {
		return "about";
	}

	@GetMapping("/user-account")
	public String userAccount() {
		return "user-account";
	}

	@GetMapping("/prices")
	public String prices() {
		return "prices";
	}

	@GetMapping("/special-offers")
	public String special() {
		return "special-offers";
	}

	@GetMapping("/events")
	public String events() {
		return "events";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

}
