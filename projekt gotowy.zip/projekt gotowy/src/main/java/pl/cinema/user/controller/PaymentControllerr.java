package pl.cinema.user.controller;

import com.stripe.exception.StripeException;
import com.stripe.model.Charge;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import pl.cinema.stripe.ChargeRequest;
import pl.cinema.user.model.Screening;
import pl.cinema.user.repository.MovieRepository;

@Controller
@RequestMapping("/payment")
public class PaymentControllerr {

    @Autowired
    private MovieRepository movieRepository;

    private Long screeningId;

    /*@GetMapping
    public String index(Model model) {
        System.out.println("xd");
        movieRepository.findById(this.screeningId).ifPresent(o -> model.addAttribute("screenings", o));
        return "payment";
    }*/

    @PostMapping
    public String submitForm(@RequestParam String screeningId, Model model) {
        System.out.println(screeningId);
        this.screeningId = Long.parseLong(screeningId);
        movieRepository.findById(this.screeningId).ifPresent(o -> model.addAttribute("screenings", o));
        return "payment";
    }

}
