package pl.cinema.user.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pl.cinema.user.model.Reservation;

import java.util.Optional;

@Repository("reservationRepository")
public interface ReservationRepository extends CrudRepository<Reservation, Long> {

    public Iterable<Reservation> findAll();

    public Optional<Reservation> findById(Long id);

    @Query("FROM Reservation r WHERE r.user.id = ?1")
    public Iterable<Reservation> findAllByUser(Long userId);

    @Transactional
    @Modifying
    @Query("UPDATE Payment p SET p.isPaid = true WHERE p.id=?1")
    void setPaid(Long reservationId);

}