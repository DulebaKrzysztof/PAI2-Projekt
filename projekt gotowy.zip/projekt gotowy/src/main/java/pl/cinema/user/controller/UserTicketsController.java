package pl.cinema.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import pl.cinema.registrationAndLogin.model.User;
import pl.cinema.registrationAndLogin.repository.UserRepository;
import pl.cinema.user.model.Reservation;
import pl.cinema.user.repository.ReservationRepository;
import pl.cinema.user.repository.TicketRepository;

import java.security.Principal;
import java.util.*;

@Controller
public class UserTicketsController {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/user-tickets")
    public String userTickets(Principal principal, Model model) {
        List<Long> fullFareList = new LinkedList<>();
        List<Long> reducedFareList = new LinkedList<>();

        User currentUser = userRepository.findByEmail(principal.getName());

        Iterable<Reservation> reservations = reservationRepository.findAllByUser(currentUser.getId());
        for(Reservation reservation: reservations) {
            fullFareList.add(ticketRepository.countTicketById(reservation.getId(), 1L));
            reducedFareList.add(ticketRepository.countTicketById(reservation.getId(), 2L));
        }

        Iterable<Long> ids = Arrays.asList(currentUser.getId());

        model.addAttribute("reservations", reservationRepository.findAllByUser(currentUser.getId()));
        model.addAttribute("fullFareList", fullFareList);
        model.addAttribute("reducedFareList", reducedFareList);

        return "user-tickets";
    }

}
