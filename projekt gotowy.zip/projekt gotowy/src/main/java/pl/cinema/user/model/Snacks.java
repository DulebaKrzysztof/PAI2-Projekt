package pl.cinema.user.model;

import javax.persistence.*;

@Entity
@Table(name = "snacks")
public class Snacks {

    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private Long id;

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public SnacksType getSnacksType() {
        return snacksType;
    }

    public void setSnacksType(SnacksType snacksType) {
        this.snacksType = snacksType;
    }

    @Column(name = "amount")
    private int amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "snacks_type_id")
    private SnacksType snacksType;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

}