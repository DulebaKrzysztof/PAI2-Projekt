package pl.cinema.user.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pl.cinema.user.model.Screening;

import java.util.List;
import java.util.Optional;

@Repository("movieRepository")
public interface MovieRepository extends CrudRepository<Screening, Long> {
    public List<Screening> findAll();

    //@Query("FROM Screening s join s.movie m")
    //public List<Screening> findAllll();

    @Query("FROM Screening s join s.movie m WHERE s.id = :screeningId")
    public Optional<Screening> findById(@Param("screeningId") Long screeningId);
}