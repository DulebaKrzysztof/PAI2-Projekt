package pl.cinema.user.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pl.cinema.user.model.Screening;
import pl.cinema.user.model.Ticket;

import java.util.Optional;

@Repository("ticketRepository")
public interface TicketRepository extends CrudRepository<Ticket, Long> {

    //@Query("SELECT SIZE(t.id) FROM Ticket t WHERE t.ticketType = 1")
    //public long sumFullFare();

    @Query("SELECT COUNT(t) FROM Ticket t WHERE t.reservation.id=?1 AND t.ticketType.id=?2")
    Long countTicketById(Long reservationId, Long ticketTypeId);

}