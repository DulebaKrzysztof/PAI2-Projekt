package pl.cinema.user.repository;

import org.springframework.data.repository.CrudRepository;
import pl.cinema.user.model.Auditorium;

public interface AuditoriumRepository extends CrudRepository<Auditorium, Long> {

}
