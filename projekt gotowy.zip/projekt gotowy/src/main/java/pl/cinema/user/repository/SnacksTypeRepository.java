package pl.cinema.user.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import pl.cinema.user.model.SnacksType;

@Repository("snacksTypeRepository")
public interface SnacksTypeRepository extends CrudRepository<SnacksType, Long> {

}
