package pl.cinema.user.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import pl.cinema.user.model.Snacks;
import pl.cinema.user.model.SnacksType;

@Repository("snacksRepository")
public interface SnacksRepository extends CrudRepository<Snacks, Long> {

}
