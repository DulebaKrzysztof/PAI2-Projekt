package pl.cinema.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pl.cinema.user.model.TicketType;

import java.util.Optional;

@Repository("ticketTypeRepository")
public interface TicketTypeRepository extends JpaRepository<TicketType, Long>{
	Optional<TicketType> findById(Long id);
}
