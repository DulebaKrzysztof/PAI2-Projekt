package pl.cinema.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import pl.cinema.registrationAndLogin.repository.UserRepository;
import pl.cinema.user.model.Screening;
import pl.cinema.user.repository.MovieRepository;

import java.security.Principal;

@Controller
@RequestMapping("/repertuar")
public class ScreeningController {

    @Autowired
    private MovieRepository mov;

    @Autowired
    private UserRepository userRepository;

    @GetMapping
    public String index(Model model) {
        model.addAttribute("screenings", mov.findAll());
        model.addAttribute("newScreening", new Screening());
        //model.addAttribute("user", new Screening());
        return "repertuar";
    }

    //@PostMapping()
    //public String save(Screening s, Model model) {
        //model.addAttribute("screenings", s);
        //System.out.println(s.getScreeningDate());
        //return "index";
    //}
}
