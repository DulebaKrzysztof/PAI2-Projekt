package pl.cinema.stripe;

import lombok.Data;

@Data
public class ChargeRequest {

    private final String currency = "PLN";
    private int amount;
    private String description;
    private String stripeEmail;
    private String stripeToken;

}