package pl.cinema.stripe;

import com.stripe.exception.StripeException;
import com.stripe.model.Charge;
import com.stripe.model.Refund;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import pl.cinema.registrationAndLogin.model.User;
import pl.cinema.registrationAndLogin.repository.UserRepository;
import pl.cinema.user.model.*;
import pl.cinema.user.repository.MovieRepository;
import pl.cinema.user.repository.ReservationRepository;
import pl.cinema.user.repository.TicketTypeRepository;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class CheckoutController {

    @Value("${stripe.keys.public}")
    private String stripePublicKey;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TicketTypeRepository ticketTypeRepository;

    /*@RequestMapping("/checkout")
    public String checkout(Model model) {
        model.addAttribute("amount", 50 * 100); // in cents
        model.addAttribute("stripePublicKey", stripePublicKey);
        //model.addAttribute("currency", "PLN");
        return "checkout";
    }*/

    @PostMapping("/checkout")
    public String goToCheckout(@RequestParam String screeningIdInput, @RequestParam String costInput,
                               @RequestParam String fullFareInput, @RequestParam String reducedFareInput, Principal principal, Model model) throws StripeException {
        int cost = Integer.parseInt(costInput);

        //create reservation
        Reservation reservation = new Reservation();

        //create payment
        Payment payment = new Payment();
        payment.setPaid(false);
        payment.setReservation(reservation);
        payment.setAmount((float) (Integer.parseInt(costInput) / 100.0));

        //create tickets + ticket type
        List<Ticket> tickets = new ArrayList<>();

        for(int i = 0; i < Integer.parseInt(fullFareInput); i++) {
            Ticket ticket = new Ticket();
            ticket.setReservation(reservation);
            Optional<TicketType> getTicketType = ticketTypeRepository.findById(1L);
            TicketType ticketType = getTicketType.get();
            ticket.setTicketType(ticketType);
            tickets.add(ticket);
        }

        for(int i = 0; i < Integer.parseInt(reducedFareInput); i++) {
            Ticket ticket = new Ticket();
            ticket.setReservation(reservation);
            Optional<TicketType> getTicketType = ticketTypeRepository.findById(2L);
            TicketType ticketType = getTicketType.get();
            ticket.setTicketType(ticketType);
            tickets.add(ticket);
        }

        //get screening
        Optional<Screening> getScreening = movieRepository.findById(Long.parseLong(screeningIdInput));
        Screening screening = getScreening.get();

        //get user
        User user = userRepository.findByEmail(principal.getName());

        reservation.setUser(user);
        System.out.println("------" + reservation.getUser().getId());
        reservation.setTickets(tickets);
        reservation.setPayment(payment);
        reservation.setScreening(screening);

        reservationRepository.save(reservation);

        model.addAttribute("amount", cost);
        model.addAttribute("stripePublicKey", stripePublicKey);
        model.addAttribute("screeningId", screeningIdInput);
        model.addAttribute("fullFare", fullFareInput);
        model.addAttribute("reducedFare", reducedFareInput);
        model.addAttribute("reservationId", reservation.getId());

        return "checkout";
    }
}