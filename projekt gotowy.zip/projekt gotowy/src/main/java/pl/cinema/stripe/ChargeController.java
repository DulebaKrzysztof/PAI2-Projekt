package pl.cinema.stripe;

import com.stripe.exception.StripeException;
import com.stripe.model.Charge;
import com.stripe.model.Refund;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import pl.cinema.registrationAndLogin.model.User;
import pl.cinema.registrationAndLogin.repository.UserRepository;
import pl.cinema.registrationAndLogin.web.UserRegistrationController;
import pl.cinema.user.model.*;
import pl.cinema.user.repository.MovieRepository;
import pl.cinema.user.repository.ReservationRepository;
import pl.cinema.user.repository.TicketRepository;
import pl.cinema.user.repository.TicketTypeRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class ChargeController {

    @Autowired
    private StripeService paymentsService;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TicketTypeRepository ticketTypeRepository;

    //@Autowired
    //private TicketRepository ticketRepository;

    @PostMapping("/charge")
    public String charge(@Param("reservationId") String reservationId, ChargeRequest chargeRequest, Model model) throws StripeException {
        chargeRequest.setDescription("Płatność za rezerwację id=" + reservationId);
        Charge charge = paymentsService.charge(chargeRequest);
        if(charge.getStatus().equals("succeeded")) {
            reservationRepository.setPaid(Long.parseLong(reservationId));

            model.addAttribute("id", charge.getId());
            model.addAttribute("status", charge.getStatus());
            model.addAttribute("chargeId", charge.getId());
            model.addAttribute("balance_transaction", charge.getBalanceTransaction());
        }
        return "charge";
    }

    @ExceptionHandler(StripeException.class)
    public String handleError(Model model, StripeException ex) {
        model.addAttribute("error", ex.getMessage());
        return "charge";
    }
}