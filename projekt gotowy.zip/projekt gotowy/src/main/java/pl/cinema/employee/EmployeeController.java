package pl.cinema.employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import pl.cinema.registrationAndLogin.model.User;
import pl.cinema.user.model.*;
import pl.cinema.user.repository.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class EmployeeController {

    @Autowired
    private MovieRepository mov;

    @Autowired
    private MovRepository movie;

    @Autowired
    private SnacksTypeRepository snacksTypeRepository;

    @Autowired
    private SnacksRepository snacksRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private TicketTypeRepository ticketTypeRepository;

    @GetMapping("/employee-panel")
    public String getEmployeePanel(Model model) {
        model.addAttribute("movies", movie.findAll());
        model.addAttribute("screenings", mov.findAll());
        model.addAttribute("snackTypes", snacksTypeRepository.findAll());
        model.addAttribute("newReservation", new Reservation());
        model.addAttribute("newSnack", new Snacks());
        return "employee-panel";
    }

    @PostMapping("/sellTickets")
    public String sellTickets(@RequestParam String reducedFareInput,
                              @RequestParam String fullFareInput,
                              @RequestParam String screeningIdInput,
                              Reservation reservation,
                              Model model) {
        model.addAttribute("movies", movie.findAll());
        model.addAttribute("screenings", mov.findAll());
        model.addAttribute("snackTypes", snacksTypeRepository.findAll());
        model.addAttribute("newReservation", new Reservation());
        model.addAttribute("newSnack", new Snacks());

        reservation.getPayment().setPaid(true);
        reservation.getPayment().setAmount((float) (reservation.getPayment().getAmount() / 100.0));

        Optional<Screening> getScreening = mov.findById(Long.parseLong(screeningIdInput));
        Screening screening = getScreening.get();
        reservation.setScreening(screening);

        //System.out.println(reservation.getScreening().getMovie().getId());


        //set user
        //set tickets

        List<Ticket> tickets = new ArrayList<>();

        for(int i = 0; i < Integer.parseInt(fullFareInput); i++) {
            Ticket ticket = new Ticket();
            ticket.setReservation(reservation);
            Optional<TicketType> getTicketType = ticketTypeRepository.findById(1L);
            TicketType ticketType = getTicketType.get();
            ticket.setTicketType(ticketType);
            tickets.add(ticket);
        }

        for(int i = 0; i < Integer.parseInt(reducedFareInput); i++) {
            Ticket ticket = new Ticket();
            ticket.setReservation(reservation);
            Optional<TicketType> getTicketType = ticketTypeRepository.findById(2L);
            TicketType ticketType = getTicketType.get();
            ticket.setTicketType(ticketType);
            tickets.add(ticket);
        }


        System.out.println(
                //reservation.getId()+""+
                        //reservation.getUser().getId()+""+
                        reservation.getPayment().getAmount()+""+
                        reservation.getPayment().getIsPaid()+""
        );

        //get user
       // User user = userRepository.findByEmail(principal.getName());
        //reservation.setUser(user);
        //System.out.println("------" + reservation.getUser().getId());
        reservation.setTickets(tickets);

        reservationRepository.save(reservation);

        //reservationRepository.save(reservation);

        return "employee-panel";
    }

    @PostMapping("/sellSnacks")
    public String sellSnacks(Snacks snack, Model model) {
        model.addAttribute("movies", movie.findAll());
        model.addAttribute("screenings", mov.findAll());
        model.addAttribute("snackTypes", snacksTypeRepository.findAll());
        model.addAttribute("newReservation", new Reservation());
        model.addAttribute("newSnack", new Snacks());

        snacksRepository.save(snack);

        return "employee-panel";
    }

}
