package pl.cinema.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import pl.cinema.user.model.Auditorium;
import pl.cinema.user.model.Movie;
import pl.cinema.user.model.Screening;
import pl.cinema.user.repository.AuditoriumRepository;
import pl.cinema.user.repository.MovRepository;
import pl.cinema.user.repository.MovieRepository;

import java.util.Optional;

@Controller
public class AdminController {

    @Autowired
    private MovieRepository mov;

    @Autowired
    private MovRepository movie;

    @Autowired
    private AuditoriumRepository auditoriumRepository;

    @GetMapping("/admin-panel")
    public String getAdminPanel(Model model) {
        model.addAttribute("movies", movie.findAll());
        model.addAttribute("screenings", mov.findAll());
        model.addAttribute("auditoriums", auditoriumRepository.findAll());
        model.addAttribute("newScreening", new Screening());
        return "admin-panel";
    }

    @PostMapping("/createScreening")
    public String createScreening(Screening screening, Model model) {
        mov.save(screening);

        model.addAttribute("movies", movie.findAll());
        model.addAttribute("screenings", mov.findAll());
        model.addAttribute("auditoriums", auditoriumRepository.findAll());
        model.addAttribute("newScreening", new Screening());
        return "admin-panel";
    }

    @PostMapping("/deleteScreening")
    public String deleteScreening(@Param("screeningId") String screeningId, Model model) {

        mov.deleteById(Long.parseLong(screeningId));

        model.addAttribute("movies", movie.findAll());
        model.addAttribute("screenings", mov.findAll());
        model.addAttribute("auditoriums", auditoriumRepository.findAll());
        model.addAttribute("newScreening", new Screening());
        return "admin-panel";
    }

}
