package pl.cinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"pl.cinema.stripe"})
@ComponentScan({"pl.cinema.registrationAndLogin"})
@ComponentScan({"pl.cinema.user"})
@ComponentScan({"pl.cinema.admin"})
@ComponentScan({"pl.cinema.employee"})
public class CinemaApplication {

    public static void main(String[] args) {
        SpringApplication.run(CinemaApplication.class, args);
    }

}
